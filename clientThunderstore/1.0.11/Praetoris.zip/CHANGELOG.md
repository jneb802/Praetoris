| `Version` | `Update Notes`    |
|-----------|-------------------|
| 1.0.2     | - edits |
| 1.0.1     | - edits |
| 1.0.0     | - Initial Release |